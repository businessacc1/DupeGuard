# DupeGuard

**Find duplicate files without uploading your data or accidentally deleting anything.**

DupeGuard is a small, open-source command-line tool that scans folders, identifies duplicate files by their SHA-256 content hash, and can safely move selected duplicates into a quarantine folder.

- 100% local: file contents never leave your computer.
- Safe by default: scanning is read-only; cleanup requires an explicit flag.
- No automatic deletion: duplicates are moved to quarantine, not permanently erased.
- Cross-platform: Windows, macOS and Linux.
- No third-party runtime dependencies.

## Requirements

- Python 3.10 or newer

## Quick start

```bash
python -m dupeguard scan ~/Documents
```

On Windows:

```powershell
py -m dupeguard scan "$HOME\Documents"
```

The scan prints groups of files with identical content and a summary of reclaimable space.

## Safely quarantine duplicates

First inspect the scan output. Then run:

```bash
python -m dupeguard scan ~/Documents --quarantine
```

DupeGuard keeps the first file in each duplicate group and moves the remaining copies to a timestamped quarantine folder. The default quarantine location is `.dupeguard-quarantine` inside the scanned directory.

To choose another quarantine folder:

```bash
python -m dupeguard scan ~/Documents --quarantine --quarantine-dir /path/to/review
```

**Important:** Review the quarantine folder before permanently deleting anything. Back up important files before running cleanup. Symbolic links are skipped.

## Options

```text
dupeguard scan PATH
  --min-size BYTES       Ignore files smaller than this (default: 1)
  --quarantine           Move duplicates to quarantine instead of read-only reporting
  --quarantine-dir PATH  Choose quarantine directory
  --json                 Print machine-readable JSON
```

## How it works

1. Walks the selected directory recursively.
2. Groups files by size (different sizes cannot have identical content).
3. Computes SHA-256 hashes for files in matching size groups.
4. Reports groups containing identical hashes.
5. With `--quarantine`, moves all but the first file in each group to quarantine.

The tool does not follow symbolic links. It does not inspect file contents beyond hashing them.

## Development

```bash
python -m unittest discover -s tests -v
```

## Roadmap

- [ ] Optional graphical interface
- [ ] Restore command for quarantined files
- [ ] Ignore patterns (`.gitignore`-style)
- [ ] Progress reporting for large scans
- [ ] Signed release binaries

## Contributing

Issues and pull requests are welcome. Please include tests for bug fixes and new behavior. See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT. See [LICENSE](LICENSE).

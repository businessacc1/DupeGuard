# Contributing

Thanks for helping make DupeGuard safer and more useful.

1. Open an issue before large changes so the approach can be discussed.
2. Keep the default behavior non-destructive.
3. Add or update unit tests for every behavior change.
4. Run `python -m unittest discover -s tests -v`.
5. Keep the tool dependency-free unless a dependency is clearly justified.

Please never include private files or personal data in bug reports.

import tempfile
import unittest
from pathlib import Path

from dupeguard.core import find_duplicates, quarantine_duplicates

class DuplicateFinderTests(unittest.TestCase):
    def test_finds_identical_content_not_just_names(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "one.txt").write_text("same data")
            (root / "two.bin").write_text("same data")
            (root / "three.txt").write_text("different")
            groups = find_duplicates(root)
            self.assertEqual(len(groups), 1)
            self.assertEqual({p.name for p in groups[0]}, {"one.txt", "two.bin"})

    def test_min_size(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a").write_text("x")
            (root / "b").write_text("x")
            self.assertEqual(find_duplicates(root, min_size=2), [])

    def test_quarantine_keeps_one_original(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.txt").write_text("duplicate")
            (root / "b.txt").write_text("duplicate")
            groups = find_duplicates(root)
            moved = quarantine_duplicates(groups, root, root / ".dupeguard-quarantine")
            self.assertEqual(len(moved), 1)
            self.assertTrue((root / "a.txt").exists())
            self.assertFalse((root / "b.txt").exists())
            self.assertEqual(moved[0].read_text(), "duplicate")

if __name__ == "__main__":
    unittest.main()

import argparse
import json
import sys
from pathlib import Path
from .core import find_duplicates, quarantine_duplicates

def human_size(size: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    value = float(size)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} TB"

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="dupeguard", description="Find duplicate files safely and locally.")
    sub = parser.add_subparsers(dest="command", required=True)
    scan = sub.add_parser("scan", help="Scan a directory for duplicate files")
    scan.add_argument("path", type=Path)
    scan.add_argument("--min-size", type=int, default=1, help="Ignore files smaller than this many bytes")
    scan.add_argument("--quarantine", action="store_true", help="Move duplicate copies to quarantine")
    scan.add_argument("--quarantine-dir", type=Path)
    scan.add_argument("--json", action="store_true", help="Output JSON")

    args = parser.parse_args(argv)
    if not args.path.exists() or not args.path.is_dir():
        parser.error(f"not a directory: {args.path}")
    if args.min_size < 0:
        parser.error("--min-size cannot be negative")

    groups = find_duplicates(args.path, min_size=args.min_size)
    reclaimable_bytes = sum(group[0].stat().st_size * (len(group) - 1) for group in groups)
    moved = []
    if args.quarantine and groups:
        destination = args.quarantine_dir or (args.path / ".dupeguard-quarantine")
        moved = quarantine_duplicates(groups, args.path, destination)

    if args.json:
        payload = {
            "scan_path": str(args.path.resolve()),
            "duplicate_groups": [
                {"size": group[0].stat().st_size, "files": [str(p) for p in group]}
                for group in groups
            ],
            "quarantined": [str(p) for p in moved],
            "reclaimable_bytes": reclaimable_bytes,
        }
        print(json.dumps(payload, indent=2))
        return 0

    if not groups:
        print("No duplicate files found.")
        return 0

    total = 0
    for index, group in enumerate(groups, 1):
        size = group[0].stat().st_size
        total += size * (len(group) - 1)
        print(f"\nGroup {index} — {human_size(size)} each")
        for path in group:
            print(f"  {path}")
    print(f"\n{len(groups)} duplicate group(s); {human_size(total)} potentially reclaimable.")
    if args.quarantine:
        print(f"Moved {len(moved)} duplicate file(s) to quarantine.")
    else:
        print("Read-only scan. Add --quarantine to move duplicate copies safely.")
    return 0

if __name__ == "__main__":
    sys.exit(main())

from __future__ import annotations

import hashlib
import os
from collections import defaultdict
from pathlib import Path
from typing import Iterable

CHUNK_SIZE = 1024 * 1024

def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(CHUNK_SIZE):
            digest.update(chunk)
    return digest.hexdigest()

def find_duplicates(root: Path, min_size: int = 1) -> list[list[Path]]:
    """Return groups of files with identical contents. Does not follow symlinks."""
    root = root.resolve()
    by_size: dict[int, list[Path]] = defaultdict(list)
    for current, dirs, filenames in os.walk(root, followlinks=False):
        dirs[:] = [
            name for name in dirs
            if not (Path(current) / name).is_symlink()
            and name != ".dupeguard-quarantine"
        ]
        for filename in filenames:
            path = Path(current) / filename
            try:
                if path.is_symlink() or not path.is_file():
                    continue
                size = path.stat().st_size
                if size >= min_size:
                    by_size[size].append(path)
            except (OSError, PermissionError):
                continue

    duplicates: list[list[Path]] = []
    for paths in by_size.values():
        if len(paths) < 2:
            continue
        by_hash: dict[str, list[Path]] = defaultdict(list)
        for path in paths:
            try:
                by_hash[_sha256(path)].append(path)
            except (OSError, PermissionError):
                continue
        duplicates.extend(group for group in by_hash.values() if len(group) > 1)

    return sorted(
        (sorted(group, key=lambda p: str(p).casefold()) for group in duplicates),
        key=lambda group: str(group[0]).casefold(),
    )

def quarantine_duplicates(
    groups: Iterable[list[Path]], scan_root: Path, quarantine_dir: Path
) -> list[Path]:
    """Move all but the first copy from each group into quarantine."""
    scan_root = scan_root.resolve()
    quarantine_dir = quarantine_dir.resolve()
    if quarantine_dir == scan_root or scan_root in quarantine_dir.parents:
        # A quarantine directory inside the scan root is fine; it is excluded from scans.
        pass
    quarantine_dir.mkdir(parents=True, exist_ok=True)
    moved: list[Path] = []
    for group in groups:
        for source in group[1:]:
            try:
                relative = source.resolve().relative_to(scan_root)
            except ValueError:
                raise ValueError(f"File is outside scan root: {source}")
            target = quarantine_dir / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                target = target.with_name(f"{target.stem}__duplicate{target.suffix}")
                counter = 2
                while target.exists():
                    target = target.with_name(f"{target.stem}_{counter}{target.suffix}")
                    counter += 1
            source.replace(target)
            moved.append(target)
    return moved
